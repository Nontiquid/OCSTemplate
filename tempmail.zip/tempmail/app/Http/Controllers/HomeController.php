<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Webklex\IMAP\Facades\Client;

use Auth;
use App;
use Cookie;
use DateTime;
use DateTimeZone;

use App\Page;
use App\Menu;

class HomeController extends Controller {

    public function __construct() {
        
    }

    public function index() {
        if(!file_exists(storage_path('installed'))) {
            return redirect()->route('Install'); 
        }
        return redirect('/'.env('TM_HOMEPAGE', 'mailbox'));
    }

    public function app($address = "") {
        if(session('locale')) {
            app()->setLocale(session('locale'));
        } else {
            app()->setLocale(env('DEFAULT_LANGUAGE', 'en'));
        }
        $this->checkCookie();
        $this->deleteOldMails();
        if($address) {
            $address = $this->checkAddress($address);
            $tm_mails = session('tm_mails');
            if(!$tm_mails) {
                $tm_mails = array();
            }
            if(!in_array($address, $tm_mails)) {
                array_push($tm_mails, $address);
                session(['tm_mails' => $tm_mails]);
            }
            session(['tm_current_mail' => $address]);
            $domains = explode(',',env('TM_DOMAINS'));
            if(empty($domains)) {
                return redirect()->route('login');
            }
            return view('app')->with('domains', $domains);
        } else {
            if(session('tm_current_mail')) {
                return redirect()->route('App', ['m' => session('tm_current_mail')]);
            }
            $stats_email = intval(env('STATS_EMAIL'));
            $stats_email = $stats_email + 1;
            $this->changeEnv(array("STATS_EMAIL" => $stats_email));
            $email_address = $this->generateRandomWord()."@".$this->generateRandomDomain();
            file_put_contents(storage_path('tmail_logs'), request()->ip()." ".date("Y/m/d h:i:sa")." ".$email_address.PHP_EOL, FILE_APPEND);
            return redirect()->route('App', ['m' => $email_address]);
        }
    }

    public function page($slug = null) {
        if(session('locale')) {
            app()->setLocale(session('locale'));
        } else {
            app()->setLocale(env('DEFAULT_LANGUAGE', 'en'));
        }
        $this->checkCookie();
        $slug = str_replace(app()->getLocale().'/', '', $slug);
        $page = Page::where('slug', $slug)->first();
        $domains = explode(',',env('TM_DOMAINS'));
        if(empty($domains)) {
            return redirect()->route('login');
        }
        if(!$page) {
            $page = new \stdClass;
            $page->title = '404 Not Found';
            $page->content = '<a href="/"><button class="go_to-home blue-purple-bg" type="button">Go to Home</button></a>';
        }
        return view('page')
            ->with('page_title', $page->title)
            ->with('page_content', $page->content)
            ->with('domains', $domains);
    }

    public function createMailID(Request $request) {
        $email = $domain = null;
        $domainList = explode(',',env('TM_DOMAINS'));
        if($request->has('email')) {
            $email = $request->input('email');
            if(in_array($email, explode(',',env('FORBIDDEN_IDS')))) {
                $email = $this->generateRandomWord();
            }
        }
        if($request->has('domain')) {
            $domain = $request->input('domain');
            if(!in_array($domain, $domainList)) {
                $domain = null;
            }
        }
        $email = preg_replace('/[^A-Za-z0-9_.+-]/', "", $email); 
        $api = false;
        if (\Request::is('api/*')) { 
            if($request->has('key')) {
                if (in_array($request->input('key'), explode(',', env('API_KEY')))) {
                    $api = true;
                } else {
                    return response()->make('Unauthorized Access. Please enter correct API Key', 401);
                }
            } else {
                return response()->make('Unauthorized Access. Please enter correct API Key', 401);
            }
        }
        if($email && $domain) {
            return $this->generateAddress($email, $domain, $api); 
        } else if ($email) {
            return $this->generateAddress($email, $this->generateRandomDomain(), $api); 
        } else if ($domain) {
            return $this->generateAddress($this->generateRandomWord(), $domain, $api); 
        } else {
            return $this->generateAddress($this->generateRandomWord(), $this->generateRandomDomain(), $api);
        }
    }

    public function deleteMailID(Request $request) {
        $tm_current_mail = session('tm_current_mail');
        $tm_mails = session('tm_mails');
        if (($key = array_search($tm_current_mail, $tm_mails)) !== false) {
            unset($tm_mails[$key]);
        }
        $tm_mails = array_values($tm_mails);
        session(['tm_mails' => $tm_mails]);
        Cookie::forever('tm_mails', json_encode($tm_mails));
        if(empty($tm_mails)) {
            $request->session()->forget('tm_current_mail');
            return response("")->withCookie(cookie()->forever('tm_mails', json_encode($tm_mails)));
        } else {
            session(['tm_current_mail' => $tm_mails[0]]);
            return response($tm_mails[0])->withCookie(cookie()->forever('tm_mails', json_encode($tm_mails)));
        }
    }

    public function getDomains(Request $request) {
        if (\Request::is('api/*')) { 
            if($request->has('key')) {
                if (!in_array($request->input('key'), explode(',', env('API_KEY')))) {
                    return response()->make('Unauthorized Access. Please enter correct API Key', 401);
                }
            } else {
                return response()->make('Unauthorized Access. Please enter correct API Key', 401);
            }
        }
        return explode(',',env('TM_DOMAINS'));
    }

    public function fetchMails(Request $request) {
        if (\Request::is('api/*')) { 
            if($request->has('key')) {
                if (!in_array($request->input('key'), explode(',', env('API_KEY')))) {
                    return response()->make('Unauthorized Access. Please enter correct API Key', 401);
                }
            } else {
                return response()->make('Unauthorized Access. Please enter correct API Key', 401);
            }
        }
        $tm_current_mail = session('tm_current_mail');
        if(!$tm_current_mail) {
            return redirect()->route('home');
        }
        $client = Client::account('default');
        $client->connect();
        $inbox = $client->getFolder('INBOX');
        if($request->has('new')) {
            $messages = $inbox->query()->to($tm_current_mail)->unseen()->get();
        } else {
            $messages = $inbox->query()->to($tm_current_mail)->get();
        }
        $return = array();
        $return["length"] = 0;
        foreach($messages as $message) {
            $mail = array();
            $date = new DateTime();
            $sender = $message->getFrom();
            $date->setTimezone(new DateTimeZone('UTC'));
            $date->setTimestamp($message->getHeaderInfo()->udate);
            $interval = date_diff(date_create(null, new DateTimeZone('UTC')), date_create($date->format('Y-m-d')));
            if($interval->format('%a') == 0) {
                $mail["short_time"] = $date->format('H:i A');
            } else {
                $mail["short_time"] = $date->format('M d');
            }
            $uid = $message->getUid();
            $mail["sender_name"] = $sender[0]->personal;
            $mail["sender_email"] = $sender[0]->mail;
            $mail["time"] = $date->format('d M Y h:i A');
            $mail["subject"] = $message->getSubject();
            $mail["text"] = $message->getTextBody();
            if(!$mail["text"]) {
                $mail["text"] = "";
            }
            $mail["html"] = $message->getHTMLBody();
            if(!$mail["html"]) {
                $mail["html"] = $mail["text"];
            }
            $mail["attachments"] = array();
            if($message->hasAttachments()) {
                $attachments = $message->getAttachments();
                foreach($attachments as $attachment) {
                    $path = public_path()."/attachments/".$uid;
                    if(!is_dir($path)) {
                        mkdir($path);
                    }
                    $attachment->save($path);
                    $item = array();
                    $item["name"] = $attachment->getName();
                    $item["path"] = url('/')."/attachments/".$uid."/".$item["name"];
                    array_push($mail["attachments"], $item);
                }
            }
            //Saving
            $return[$uid] = $mail;
            $return["length"]++;
        }
        if($request->has('new') && $return["length"] > 0) {
            $stats_received = intval(env('STATS_RECEIVED'));
            $stats_received = $stats_received + $return["length"];
            $this->changeEnv(array("STATS_RECEIVED" => $stats_received));
        }
        return $return;
    }

    public function deleteMail(Request $request) {
        if($request->has('uid')) {
            $uid = intval($request->input('uid'));
            $client = Client::account('default');
            $client->connect();
            $inbox = $client->getFolder('INBOX');
            $message = $inbox->getMessage($uid);
            if($message) {
                $message->delete();
                return $uid;
            }
        }
    }

    protected function generateAddress($email = null, $domain = null, $api = false) {
        if($email && $domain) {
            $tm_mails = session('tm_mails');
            if(!$tm_mails) {
                $tm_mails = array();
            }
            if(!in_array($email."@".$domain, $tm_mails)) {
                array_push($tm_mails, $email."@".$domain);
            }
            session(['tm_mails' => $tm_mails]);
            $stats_email = intval(env('STATS_EMAIL'));
            $stats_email = $stats_email + 1;
            $this->changeEnv(array("STATS_EMAIL" => $stats_email));
            file_put_contents(storage_path('tmail_logs'), request()->ip()." ".date("Y/m/d h:i:sa")." ".$email."@".$domain.PHP_EOL, FILE_APPEND);
            if($api) {
                session(['tm_current_mail' =>$email."@".$domain]);
                return $email."@".$domain;
            }
            return redirect()->route('App', ['m' => $email."@".$domain])->withCookie(cookie()->forever('tm_mails', json_encode($tm_mails)));
        } else {
            return redirect()->route('home');
        }
    }

    protected function checkAddress($address = null) {
        if($address) {
            $emaildomain = explode("@", $address);
            $domainList = explode(',',env('TM_DOMAINS'));
            $emaildomain[0] = preg_replace('/[^A-Za-z0-9_.+-]/', "", $emaildomain[0]);
            if(!in_array($emaildomain[1], $domainList)) {
                $emaildomain[1] = $this->generateRandomDomain();
            } 
            if(!in_array($emaildomain[0], explode(',',env('FORBIDDEN_IDS')))) {
                return $emaildomain[0]."@".$emaildomain[1];
            } else {
                return $this->generateRandomWord()."@".$emaildomain[1];
            }
        } else {
            return $this->generateRandomWord()."@".$this->generateRandomDomain();
        }
        
    }

    protected function generateRandomWord() {
        $c  = 'bcdfghjklmnprstvwz'; //consonants except hard to speak ones
        $v  = 'aeiou';              //vowels
        $a  = $c.$v;                //both
        $random = '';
        for( $j = 0 ; $j < 2 ; $j++ ){
            $random .= $c[rand(0, strlen($c) - 1)];
            $random .= $v[rand(0, strlen($v) - 1)];
            $random .= $a[rand(0, strlen($a) - 1)];
        }
        return $random;
    }

    protected function generateRandomDomain() {
        $domainList = explode(',',env('TM_DOMAINS'));
        $count = count($domainList);
        $selectedDomain = rand(1, $count) - 1;
        return $domainList[$selectedDomain];
    }

    protected function checkCookie() {
        if(!session('tm_current_mail')) {
            $tm_mails = json_decode(Cookie::get('tm_mails'));
            session(['tm_mails' => $tm_mails]);
            if(isset($tm_mails[0])) {
                session(['tm_current_mail' => $tm_mails[0]]);
            }
        }
    }

    protected function changeEnv($data = array()){
        if(count($data) > 0){
            $env = file_get_contents(base_path() . '/.env');
            $env = explode("\n", $env);
            foreach((array)$data as $key => $value) {
                if($key == "_token") {
                    continue;
                }
                $notfound = true;
                foreach($env as $env_key => $env_value) {
                    $entry = explode("=", $env_value, 2);
                    if($entry[0] == $key){
                        $env[$env_key] = $key . "=\"" . $value."\"";
                        $notfound = false;
                    } else {
                        $env[$env_key] = $env_value;
                    }
                }
                if($notfound) {
                    $env[$env_key + 1] = "\n".$key . "=\"" . $value."\"";
                }
            }
            $env = implode("\n", $env);
            file_put_contents(base_path() . '/.env', $env);
            return true;
        } else {
            return false;
        }
    }

    protected function deleteOldMails() {
        if(env('DELETE_AFTER_DAYS', 0)) {
            $client = Client::account('default');
            $client->connect();
            $inbox = $client->getFolder('INBOX');
            $messages = $inbox->query()->before(now()->subDays(env('DELETE_AFTER_DAYS')))->limit(5, 1)->get();
            foreach($messages as $message) { 
                $message->delete();
            }
        }
    }

    public function customCss() {
        $primary = env('TM_COLOR_PRIMARY', '#673AE2');
        $secondary = env('TM_COLOR_SECONDARY', '#8fcb21');
        $tertiary = env('TM_COLOR_TERTIARY', '#de881e');
        $return = "
        header .tm-menu nav ul li a:hover {
            color: ".$primary.";
        }
        main .tm-message .mail-delete i {
            color: ".$primary.";
        }
        main .tm-message .subject {
            color: ".$primary.";
        }
        .primary-color {
            color: ".$primary.";
        }
        main .tm-message .attachments a {
            border: 1px solid ".$primary.";
        }
        header .tm-menu nav.main ul li a:hover {
            border-bottom: 2px solid ".$primary." !important;
        }
        main .tm-message .attachments a:hover {
            background: ".$primary.";
        }
        main .tm-sidebar .tm-create input[value=Create][type=submit] {
            background: ".$secondary.";
        }
        main .tm-sidebar .tm-create input[value=Random][type=submit] {
            background: ".$tertiary.";
        }
        .primary-background {
            background: ".$primary.";
        }
        header .tm-mobile-menu {
            background: ".$primary.";
        }
        main .tm-sidebar {
            background: ".$primary.";
        }
        header .tm-logo {
            background: ".$primary.";
        }
        main .tm-message .close-mail-content {
            background: ".$primary.";
        }
        ";
        return response($return, 200)->header('Content-Type', 'text/css');
    }

    public function changeLocale(Request $request) {
        if($request->has('locale')) {
            $locale = $request->input('locale');
            if(in_array($locale, config('app.locales'))) {
                session(['locale' => $locale]);
                app()->setLocale($locale);
                return "done";
            }
        }
    }
}
