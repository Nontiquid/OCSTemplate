<?php $__env->startSection('addonCSS'); ?>
<link href="<?php echo e(asset('css/admin.css?v='.env('APP_VERSION'))); ?>" rel="stylesheet">
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addonJS'); ?>
<script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
<script>
    var quill = new Quill('#editor', {
        theme: 'snow'
    });
</script>
<script>
    document.getElementById("btnSubmit").addEventListener("click", function(){
        var changedContent = quill.root.innerHTML;
        document.getElementById("content").innerHTML = changedContent;
        document.getElementById("pageForm").submit();
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row hp-editor">
            <div class="col-md-12">
                <div class="row">
                    <h3 class="col-md-9 page_title">Edit Page - #<?php echo e($page->id); ?></h3>
                    <a class="col-md-3 button-return" href="<?php echo e(route('AdminPages')); ?>">Return to All Pages</a>
                </div>
                <form method="POST" id="pageForm" action="<?php echo e(route('AdminPageEditSubmit')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($page->id); ?>">
                    <div class="page_title">
                        <label for="title">Page Title</label>
                        <input id="title" type="text" name="title" value="<?php echo e($page->title); ?>" placeholder="Page Title" required>
                    </div>
                    <div class="page_slug">
                        <label for="title">Page Slug (ex. home, about)</label>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                              <span class="input-group-text" id="basic-addon1"><?php echo e(env('APP_URL')); ?>/</span>
                            </div>
                            <input id="slug" type="text" name="slug" value="<?php echo e($page->slug); ?>" placeholder="Page Slug" required>
                        </div>
                    </div>
                    <div class="page_content">
                        <label for="content">Page Content</label>
                        <div id="editor"><?php echo $page->content; ?></div>
                    </div>
                    <textarea id="content" name="content"></textarea>
                    <button class="blue-bg" type="button" id="btnSubmit">Submit</button>
                </form>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\TMail\resources\views/admin/page.blade.php */ ?>