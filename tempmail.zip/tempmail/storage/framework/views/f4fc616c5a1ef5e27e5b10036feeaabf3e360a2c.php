<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 tm-sidebar">
            <div class="tm-create <?php echo e((session('tm_current_mail')) ? 'show-button' : ''); ?>">
                <?php if(session('tm_current_mail')): ?>
                <a href="<?php echo e(route('App')); ?>" class="btn-backtoapp"><i class="fas fa-angle-double-left"></i><?php echo e(__('app.goback')); ?></a>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('MailIDCreateCustom')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="email" placeholder="<?php echo e(__('app.enter')); ?>">
                    <input type="hidden" name="domain" value="<?php echo e($domains[0]); ?>">
                    <div class="tm-domain-selector">
                        <div class="row current-id">
                            <div class="col-10" id="selected-domain"><?php echo e("@".$domains[0]); ?></div>
                            <div class="col-2"><i class="fas fa-chevron-down"></i></div>
                        </div>
                        <div class="row all-ids">
                            <div class="col-10">
                                <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="domain-selector" href="#"><?php echo e("@".$domain); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <input type="submit" action="Create" value="<?php echo e(__('app.create')); ?>">
                </form>
                <span><?php echo e(__('app.or')); ?></span>
                <form method="POST" action="<?php echo e(route('MailIDCreateRandom')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="submit" action="Random" value="<?php echo e(__('app.random')); ?>">
                </form>
            </div>
            <div class="tm-ads">
                <?php echo e(env('TM_AD_SPACE_1')); ?>

            </div>
        </div>
        <div class="col-md-9 tm-content">
            <h3 class="page_title"><?php echo e($page_title); ?></h3>
            <p class="page_content"><?php echo $page_content; ?></p>
            <?php echo e(env('TM_AD_SPACE_2')); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>         

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TMail\resources\views/page.blade.php ENDPATH**/ ?>