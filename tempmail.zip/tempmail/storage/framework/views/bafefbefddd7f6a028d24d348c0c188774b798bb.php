<?php $__env->startSection('addonCSS'); ?>
<link href="<?php echo e(asset('css/admin.css?v='.env('APP_VERSION'))); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addonJS'); ?>
<script src="<?php echo e(asset('js/admin/update.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h3 class="page_title">Software Update</h3>
            <div id="update-progress">

            </div>
            <?php if(isset($manual) && $manual): ?>
            <div class="d-none" id="manual" link="<?php echo e(route('AdminApplyUpdate')); ?>">TRUE</div>
            <?php else: ?>
            <p class="description_details">
                <?php if($update): ?>
                <strong>Update Available!</strong> 
                <br>Click on below button to update your website. <br>Please make sure you had created a backup before applying update.
                <br><br><br><a class="blue-bg normal-button" id="update-button" link="<?php echo e(route('AdminApplyUpdate')); ?>">Update TMail</a>
                <?php else: ?> 
                You're on Latest version of TMail!
                <?php endif; ?>
            </p>
            <br><br><br>
            <div class="description_box_title">
                <h3>Manual Software Update</h3>
            </div>
            <br>
            <form method="POST" action="<?php echo e(route('AdminUpdateManual')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="file" id="update" name="update" required>
                <br><br>
                <button type="submit" class="btn btn-primary blue-purple-bg normal-button">
                    <?php echo e(__('Submit')); ?>

                </button>
            </form>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TMail\resources\views/admin/update.blade.php ENDPATH**/ ?>