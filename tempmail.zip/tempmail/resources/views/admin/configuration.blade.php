@extends('admin.layout')

@section('addonCSS')
<link href="{{ asset('css/admin.css') }}" rel="stylesheet">
<style>
.addIcons {
    font-size: 36px;
    cursor: pointer;
}
.domains {
    margin-top: 5px;
}
.domains input {
    width: 100%;
    margin-top: 5px;
}
</style>
@endsection

@section('addonJS')
<script>
$("#addDomain").click(function(){
    $("#addDomain").before('<div class="domains"><input type="text" name="domain[]" placeholder="Enter Domain"></div>');
});
$("#addAPI").click(function(){
    $("#addAPI").before('<div class="domains"><input type="text" name="api[]" placeholder="Enter API Key"></div>');
});
$("#addForbidden").click(function(){
    $("#addForbidden").before('<div class="domains"><input type="text" name="forbidden[]" placeholder="Enter Forbidden ID (without domain)"></div>');
});
</script>
@endsection

@section('content')
<h3 class="page_title">{{ $page_title }}</h3>

<form method="POST" action="{{ route('AdminConfigurationSubmit') }}" enctype="multipart/form-data">
    @csrf
    <div class="form-group">
        <label for="logo" class="col-form-label">Logo</label>
        <div class="field">
            <input type="file" id="logo" class="{{ $errors->has("logo") ? ' is-invalid' : '' }}" name="logo">
            @if ($errors->has("logo"))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first("logo") }}</strong>
                </span>
            @endif
        </div>
    </div>
    @foreach($env as $key => $value)
    @if($key == "APP_FORCE_HTTPS")
    <div class="form-group">
        <label for="{{$key}}" class="col-form-label">Force SSL?</label>
        <div class="field">
            <select id="{{$key}}" class="form-control{{ $errors->has($key) ? ' is-invalid' : '' }}" name="{{$key}}">
                <option value="true" {{ $value ? 'selected' : '' }}>Yes</option>
                <option value="false" {{ $value ? '' : 'selected' }}>No</option>
            </select>
            @if ($errors->has($key))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first($key) }}</strong>
                </span>
            @endif
        </div>
    </div>
    @elseif($key == "TM_DOMAINS")
    <div class="form-group">
        <label for="{{$key}}" class="col-form-label">Domains</label>
        <div class="field">
            @foreach( explode(',', $value) as $domain )
            <div class="domains">
                <input id="domain" type="text" name="domain[]" placeholder="Enter Domain" value="{{ $domain }}">
            </div>
            @endforeach
            <div class="addIcons" id="addDomain">+</div>
            @if ($errors->has($key))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first($key) }}</strong>
                </span>
            @endif
        </div>
    </div>
    @elseif($key == "API_KEY")
    <div class="form-group">
        <label for="{{$key}}" class="col-form-label">API Key(s)</label>
        <div class="field">
            @foreach( explode(',', $value) as $api )
            <div class="domains">
                <input id="api" type="text" name="api[]" placeholder="Enter API Key" value="{{ $api }}">
            </div>
            @endforeach
            <div class="addIcons" id="addAPI">+</div>
            @if ($errors->has($key))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first($key) }}</strong>
                </span>
            @endif
        </div>
    </div>
    @elseif($key == "FORBIDDEN_IDS")
    <div class="form-group">
        <label for="{{$key}}" class="col-form-label">Forbidden ID(s)</label>
        <div class="field">
            @foreach( explode(',', $value) as $ids )
            <div class="domains">
                <input id="ids" type="text" name="forbidden[]" placeholder="Enter Forbidden ID (without domain)" value="{{ $ids }}">
            </div>
            @endforeach
            <div class="addIcons" id="addForbidden">+</div>
            @if ($errors->has($key))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first($key) }}</strong>
                </span>
            @endif
        </div>
    </div>
    @elseif($key == "IMAP_VALIDATE_CERT")
    <div class="form-group">
        <label for="{{$key}}" class="col-form-label">Enable SSL Check (IMAP)?</label>
        <div class="field">
            <select id="{{$key}}" class="form-control{{ $errors->has($key) ? ' is-invalid' : '' }}" name="{{$key}}">
                <option value="true" {{ $value ? 'selected' : '' }}>Yes</option>
                <option value="false" {{ $value ? '' : 'selected' }}>No</option>
            </select>
            @if ($errors->has($key))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first($key) }}</strong>
                </span>
            @endif
        </div>
    </div>
    @elseif (\strpos($key, 'AD_SPACE_') !== false) 
    <div class="form-group">
        <label for="{{$key}}" class="col-form-label">{{ ucwords(strtolower(str_replace("_"," ",str_replace("TM_"," ",$key)))) }}</label>
        <div class="field">
            <textarea id="{{$key}}" type="text" class="form-control{{ $errors->has($key) ? ' is-invalid' : '' }}" name="{{ $key }}">{{ $value }}</textarea>
            @if ($errors->has($key))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first($key) }}</strong>
                </span>
            @endif
        </div>
    </div>
    @elseif (\strpos($key, 'CUSTOM_') !== false) 
    <div class="form-group">
        <label for="{{$key}}" class="col-form-label">{{ ucwords(strtolower(str_replace("_"," ",$key))) }}</label>
        <div class="field">
            <textarea id="{{$key}}" type="text" class="form-control{{ $errors->has($key) ? ' is-invalid' : '' }} custom_code" name="{{ $key }}">{{ $value }}</textarea>
            @if ($errors->has($key))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first($key) }}</strong>
                </span>
            @endif
        </div>
    </div>
    @elseif (\strpos($key, 'TM_COLOR_') !== false) 
    <div class="form-group">
        <label for="{{$key}}" class="col-form-label">{{ ucwords(strtolower(str_replace("_"," ",str_replace("TM_"," ",$key)))) }}</label>
        <div class="field">
            <input id="{{$key}}" type="color" class="form-control{{ $errors->has($key) ? ' is-invalid' : '' }}" name="{{ $key }}" value="{{ $value }}">
            @if ($errors->has($key))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first($key) }}</strong>
                </span>
            @endif
        </div>
    </div>
    @elseif($key == "TM_HOMEPAGE") 
    <div class="form-group">
        <label for="{{$key}}" class="col-form-label">Select Home Page</label>
        <div class="field">
            <select id="{{$key}}" class="form-control{{ $errors->has($key) ? ' is-invalid' : '' }}" name="{{$key}}">
                <option value="mailbox" {{ ($value == 'mailbox') ? 'selected' : '' }}>App (Auto Generate ID)</option>
                @foreach($pages as $page)
                <option value="{{ $page->slug }}" {{ ($value == $page->slug) ? 'selected' : '' }}>{{ $page->title }}</option>
                @endforeach
            </select>
            @if ($errors->has($key))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first($key) }}</strong>
                </span>
            @endif
        </div>
    </div>
    @elseif($key == "DEFAULT_LANGUAGE") 
    <div class="form-group">
        <label for="{{$key}}" class="col-form-label">Select Language</label>
        <div class="field">
            <select id="{{$key}}" class="form-control{{ $errors->has($key) ? ' is-invalid' : '' }}" name="{{$key}}">
                @foreach(config('app.locales') as $locale)
                <option value="{{ $locale }}" {{ ($value == $locale) ? 'selected' : '' }}>{{ $locale }}</option>
                @endforeach
            </select>
            @if ($errors->has($key))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first($key) }}</strong>
                </span>
            @endif
        </div>
    </div>
    @else  
    <div class="form-group">
        <label for="{{$key}}" class="col-form-label">{{ ucwords(strtolower(str_replace("_"," ",str_replace("TM_"," ",$key)))) }}</label>
        <div class="field">
            <input id="{{$key}}" type="text" class="form-control{{ $errors->has($key) ? ' is-invalid' : '' }}" name="{{ $key }}" value="{{ $value }}">
            @if ($errors->has($key))
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $errors->first($key) }}</strong>
                </span>
            @endif
        </div>
    </div>
    @endif
    @endforeach
    <div class="form-group row mb-0">
        <div class="col-md-12 hp-editor menu-form">
            <button class="blue-bg" type="submit">Save</button>
        </div>
    </div>
</form>
@endsection    
