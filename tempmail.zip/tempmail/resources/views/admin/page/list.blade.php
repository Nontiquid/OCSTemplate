@extends('layout')

@section('addonCSS')
<link href="{{ asset('css/admin.css') }}" rel="stylesheet">
@endsection

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12 tm-admin tm-content">
            <div class="row">
                <div class="col-md-6">
                    <div class="page_title">
                        <h3>All Pages</h3>
                    </div>
                </div>
                <div class="col-md-6">
                    <a class="primary-background" href="">Add New Page</a>
                </div>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Slug</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Home</td>
                        <td>/home</td>
                        <td>
                            <button type="button" value="View">View</button>
                            <button type="button" value="Edit">Edit</button>
                            <button type="button" value="Delete">Delete</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection  
