@extends('layout')

@section('addonCSS')
<link href="{{ asset('css/admin.css') }}" rel="stylesheet">
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
@endsection

@section('addonJS')
<script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
<script>
    var quill = new Quill('#editor', {
        theme: 'snow'
    });
</script>
<script>
    document.getElementById("btnSubmit").addEventListener("click", function(){
        var changedContent = quill.root.innerHTML;
        document.getElementById("content").innerHTML = changedContent;
        document.getElementById("pageForm").submit();
    });
</script>
@endsection

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12 tm-admin tm-content">
            <div class="page_title">
                <h3>Edit Page - <small>{{ $page->title }}</small></h3>
            </div>
            <form method="POST" id="pageForm" action="{{ route('AdminPageNewSubmit') }}">
                @csrf
                <div class="page_slug">
                    <label for="slug">Page Slug (ex. home/about)</label>
                    <input id="slug" type="text" name="slug" value="{{ $page->slug }}" placeholder="Page Slug" required>
                </div>
                <div class="page_title">
                    <label for="title">Page Title</label>
                    <input id="title" type="text" name="title" value="{{ $page->title }}" placeholder="Page Title" required>
                </div>
                <div class="page_content">
                    <label for="content">Page Content</label>
                    <div id="editor">{!! $page->content !!}</div>
                </div>
                <textarea id="content" name="content"></textarea>
                <button class="blue-purple-bg" type="button" id="btnSubmit">Submit</button>
            </form>
        </div>
    </div>
</div>
@endsection  
