<!DOCTYPE html>
<html lang="en">
<head>

    <!-- meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport"       content="width=device-width, initial-scale=1.0">
    <meta name="description"    content="IEPHSSH is the best ssh provider">
    <meta name="keywords"       content="ieph, sshieph, premium ssh, ssh, iephxuns, ieph-uns">
    <meta name="author"         content="Coderspoint">

    <!-- Site title -->
    <title>IEPHSSH THE BEST SSH AND FASTEST SSH PROVIDER</title>

    <!-- favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="/assets/img/logo.png">

    <!-- Bootstrap css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!--Font Awesome css -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">

    <!-- Normalizer css -->
    <link href="assets/css/normalize.css" rel="stylesheet">

    <!-- Owl Carousel css -->
    <link href="assets/css/owl.carousel.min.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">

    <!-- Magnific popup css -->
    <link href="assets/css/magnific-popup.css" rel="stylesheet">

    <!-- Site css -->
    <link href="assets/css/style.css" rel="stylesheet">

    <!-- Responsive css -->
    <link href="assets/css/responsive.css" rel="stylesheet">
	
	
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9] -->
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	   
	  
<link href="assets/css/custom.css" rel="stylesheet">
   
    <!--[endif]-->

</head>

<body>

    





    <!-- Navigation area starts -->
    <div class="menu-area navbar-fixed-top">
        <div class="container">
            <div class="row">

                <!-- Navigation starts -->
                <div class="col-md-12">
                    <div class="mainmenu">
                        <div class="navbar navbar-nobg">
                            <div class="navbar-header">
                                <a class="navbar-brand" href="/index.php"><span>IEPH</span>SSH</a>
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>

                            <div class="navbar-collapse collapse">
                                <nav>
                                    <ul class="nav navbar-nav navbar-right">
                                        <li class="active"><a href="/index.php">HOME</a></li>
                                        <li><a href="/index.php#ssh">SSH</a></li>
                                        <li><a href="/tos.php">TOS</a></li>
                                        <li><a href="/privacy.php">Privacy Policy</a></li>
                                        <li><a href="/index.php#contact">CONTACT</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Navigation ends -->

            </div>
        </div>
    </div>
    <!-- Navigation area ends -->