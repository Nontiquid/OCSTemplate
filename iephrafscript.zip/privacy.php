<?php include('header.php'); ?>

<ul class="breadcrumb">
  <li><a href="/index.php"><i class="fa fa-home"></i>Home</a></li>
  <li style="text-transform:uppercase">privacy</li>
</ul>

<section class="pricing-area section-big">
        <div class="container">
		   <div class="row">
		   <div class="col-md-12">
		   <h3>Privacy Policy</h3>
<p>KAYO NG BAHALA MAG LAGAY DITO</p>
</div>
</div>
</div>
    </section>
	
	<?php include('footer.php'); ?>