<!-- Footer area starts -->
    <footer class="footer-area">
        <div class="container">
            <p>&copy; 2019 Copyright SSHIEPH
      
     <!-- Mahiya naman wag tanggalin credits -->
            <br>Credits: <a href="https://ieph-uns"><i class="fa fa-heart" style="color:red"></i>IEPH-Raf</a></p>
            
        </div>
    </footer>
    <!-- Footer area ends -->

    <!-- Latest jQuery -->
    <script src="assets/js/jquery.min.js"></script>

    <!-- Bootstrap js-->
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Owl Carousel js -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Mixitup js -->
    <script src="assets/js/jquery.mixitup.js"></script>

    <!-- Magnific popup js -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>

    <!-- Waypoint js -->
    <script src="assets/js/jquery.waypoints.min.js"></script>

    <!-- Ajax Mailchimp js -->
    <script src="assets/js/jquery.ajaxchimp.min.js"></script>
    <script src="assets/js/jquery.script.js"></script>
	
    <!-- Main js-->
    <script src="assets/js/main_script.js"></script>
</body>
</html>