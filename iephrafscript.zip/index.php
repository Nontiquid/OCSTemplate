<?php 
include('config.php');

include('header.php'); 

$sql = "SELECT * FROM server";
$result = $db->query($sql);

$sql1="select count('id') from usercreated";
$result1=mysqli_query($db,$sql1);
$row1=mysqli_fetch_array($result1);

$sql2="select sum(createtoday) as today from server";
$result2=mysqli_query($db,$sql2);

$sql3="select count('id') from server";
$result3=mysqli_query($db,$sql3);
$row3=mysqli_fetch_array($result3);

 $svname = null;
 $svip = null;

$counter = 1; ?>



    <!-- Slider area starts -->
    <section id="slider" class="slider-area">
        <div class="table">
            <div class="table-cell">
                <div class="intro-text">
                    <div class="container">
                        <div class="row">

                            <!-- intro image -->
                            <div class="col-md-6 col-md-push-6 col-sm-12 intro-img">
                                <img src="assets/img/slider/2.png" alt="">
                            </div>

                            <!-- intro text -->
                            <div class="col-md-6 col-md-pull-6 col-sm-12">
                                <h1>Welcome to IEPHSSH</h1>
                                <p>Our service is free for everyone</p>
                                <ul>
                                    <li>• SSH</li>
                                    <li>• SSL</li>
                                    <li>• OVPN</li>
                                </ul>
                                <a href="#ssh" class="btn btn-lg btn-white">Get Started</a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Slider area ends -->


    <!-- Hero boxes starts -->
    <div class="hero-boxes">
        <div class="container">
            <div class="row">

                <!-- Hero box -->
                <div class="col-md-4 col-sm-4">
                    <div class="hero-box">
                        <img src="assets/img/hero/cursor.png" alt="">
                        <div class="hero-overlay">
                            <h2>Instant Setup</h2>
                            <p>A wonderful serenity has taken possession of my entire soul which I enjoy with my whole heart.</p>
                        </div>
                    </div>
                </div>

                <!-- Hero box -->
                <div class="col-md-4 col-sm-4">
                    <div class="hero-box">
                        <img src="assets/img/hero/rocket-launch.png" alt="">
                        <div class="hero-overlay">
                            <h2>Fast Loading</h2>
                            <p>A wonderful serenity has taken possession of my entire soul which I enjoy with my whole heart.</p>
                        </div>
                    </div>
                </div>

                <!-- Hero box -->
                <div class="col-md-4 col-sm-4">
                    <div class="hero-box">
                        <img src="assets/img/hero/headphones.png" alt="">
                        <div class="hero-overlay">
                            <h2>24/7 Support</h2>
                            <p>A wonderful serenity has taken possession of my entire soul which I enjoy with my whole heart. </p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- Hero boxes ends -->


    <!-- Price area starts -->
    <section id="ssh" class="pricing-area section-big">
        <div class="container">

            <div class="row">
                <div class="col-md-12">
                    <div class="section-title text-center">
                        <h2>Choose Your Server</h2>                        
                        <p>We provide the best server for everyone</p>
                    </div>
                </div>
            </div>

            <div class="row">

                <!-- Pricing Table -->
				<?php 
					if($result->num_rows > 0) {
					while($row = $result->fetch_assoc())
						{
$svname = $row["servername"];
				      $svip = $row["serverip"];
$svid = $row["id"];					  ?>
            <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="price-item featured" data-connectors="1">
					
					<div class="info">
                        <p class="level">Server <?php echo $counter; ?></p>
                            <p class="price">
                                <span class="number" style="text-transform:uppercase"><?php echo $svname; ?></span>
                            </p>
                        </div>
                        <div class="features">
                            <ul>
                         <li>Host: <?php echo $svip; ?></li>

<li>Active	: 7 Days</li>
<li>Protocol : TCP & UDP</li>
<li>OpenSSH	: 22, 444</li>
<li>SSL : 442</li>
<li>Dropbear	: 443,143</li>
<li>Squid : 8080, 8000, 8888, 3128</li>
                            </ul>
                        </div>
                        <a class="btn" href="/create.php?id=<?php echo $svid; ?>">CREATE</a>
						
                    </div>
                </div>
<?php   $counter++;
				}
				}
				?>
                

            </div>
        </div>
    </section>
    <!-- Price area ends -->

   <!-- STATISTIC OF YOUR SITE -->
   
                  <div class="boxed">
				  <h2>IEPH SSH STATISTIC</h2>
				  <br>
					<?php while ($row2 = mysqli_fetch_assoc($result2)) { ?>
					<i class="fa fa-user"></i>CREATED TODAY: <?php echo $row2['today']; ?>
					<?php } ?>
					<br>
					<i class="fa fa-group"></i>TOTAL CREATED IN THE SERVER: <?php echo $row1[0]; ?>
					<br>
					<i class="fa fa-cloud"></i>TOTAL OF SERVER: <?php echo $row3[0]; ?>
					<br><br>
					</div>
					
					
				<!-- END OF STATISTIC -->
				
				
				
				 <section class="pricing-area section-big">
        <div class="container">
		   <div class="row">
		   <div class="col-md-12">
		   <h3>What is SSH?</h3>
Sometimes, we keep our servers local. We can plug in a keyboard, mouse and monitor and control the server, as needed. More effectively and far more commonly these days, a lot of our servers live in a colo (co-location facility where many, many servers are hosted in an appropriate environment with cooling, throughput of data, physical security, etc.) or servers are virtualized like in Amazon Web Services or Microsoft Azure. So, without physical access to get to a shell, we can use Secure Shell. 

SSH uses an encrypted network connection to connect to a server and allows the user to run shell commands to a server remotely as if they were sitting right in front of it. It is a step up from something called Telnet which essentially does the same thing but does not use an encrypted connection. Telnet comes through as plaintext. Telnet would be the HTTP to SSH's HTTPS in this analogy. It is mostly deprecated this day and age. 

Now, when I say server, let me clarify something: Any computer can be SSH'd to so long as an SSH server instance is running on that machine. Most server OSes have an SSH server instance at least installed on them that might just need to be activated with a few settings. But, even your home computer could technically run an SSH server and be accessed via a secure shell client (assuming other security processes, such as firewalls or anti-viruses allow the connection to be made).
<br><br>


<h3>What is OVPN?</h3>
OpenVPN is both a VPN protocol and software that uses VPN techniques to secure point-to-point and site-to-site connections. Currently, it's one of the most popular VPN protocols among VPN users. 

Programmed by James Yonan and released in 2001, OpenVPN is one of the only open-source VPN protocols that also has its own open-source application (SoftEther being the other one).
</div></div>
</div>
    </section>
				
				

    <!-- Contact area starts -->
    <section id="contact" class="contact-area section-big">
        <div class="container">

            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="section-title">
                        <h2>Contact Us</h2>
                        <p>Thank you for choosing us you can contact us when you have question or report bug to our site</p>
                    </div>
                </div>
            </div>

            <div class="row">

                <div class="col-md-6">

                    <!-- Contact form starts -->
                    <div class="contact-form">

                        <form id="ajax-contact" action="http://html.web-bean.net/lanhost/assets/mailer.php" method="post">
                            <div class="form-group in_name">
                                <input type="text" name="name" class="form-control" id="name" placeholder="Name" required="required">
                            </div>
                            <div class="form-group in_email">
                                <input type="email" name="email" class="form-control" id="email" placeholder="Email" required="required">
                            </div>
                            <div class="form-group in_message">
                                <textarea rows="5" name="message" class="form-control" id="message" placeholder="Message" required="required"></textarea>
                            </div>
                            <div class="actions">
                                <input type="submit" value="Send" name="submit" id="submitButton" class="btn" title="Submit Your Message!">
                            </div>
                        </form>

                        <!-- Submition status -->
                        <div id="form-messages"></div>

                    </div>
                    <!-- Contact form ends-->
                </div>

                <div class="col-md-6">

                    <div class="address">
                        <h3 class="subtitle">Contact Info</h3>
                        <div class="address-box clearfix">
                            <p>1502 N Elm St, Fairmont, MN, 56031 <br>United States</p>
                        </div>
                        <div class="address-box clearfix">
                            <p><a href="tel:015110022">+00 123-456-789</a></p>
                        </div>
                        <div class="address-box clearfix">
                            <p><a href="mailto:email@yourdomain.com">email@yourdomain.com</a></p>
                        </div>
                        <div class="address-box clearfix">
                            <p><a href="http://www.yourdomain.com/">www.yourdomain.com</a></p>
                        </div>

                        <ul class="social-links">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                            <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                        </ul>

                    </div>

                </div>


            </div>

        </div>
    </section>
    <!-- Contact area ends -->


<?php include('footer.php'); ?>
