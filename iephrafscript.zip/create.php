<?php 
include('config.php');

if (isset($_GET['id'])) {
		$id_no1 = $_GET['id'];
		$update = true;
		$record7 = mysqli_query($db, "SELECT * FROM server WHERE id=$id_no1");

		if (count($record7) == 1 ) {
			$n1 = mysqli_fetch_array($record7);
			$svname = $n1["servername"];
        $svip = $n1["serverip"];
		$svid = $n1["id"];
		$create = $n1["createtoday"];
		}

	}

		
	if(isset($_POST['insert']))
	{
$namenya = $_POST['user'] . '-sshieph';
$query = "INSERT INTO usercreated(servername, serverip, username, password) VALUES ('$svname','$svip','$namenya','$_POST[password]')";
$query2 ="UPDATE server SET createtoday = createtoday+1 WHERE id = $svid";
	}
	
	
$hosts= $svip;
$nDays = '7';
$vpspass = 'passngvpsmo'; // lagay mo dito pass ng vps mo

$port_ssh= '22, 143';						// SSH Ports
$port_dropbear= '443, 143';					// Dropbear Ports
$port_ssl= '442';							// SSL Ports
$port_squid= '3128, 8080, 8888, 8000';			// Squid Ports
$ovpn_client= ''.$hosts.'/client.ovpn';		// OpenVPN Client Config


 $succ = null;
 $error = null;
 $username = null;
 $password1 = null;
 $res = null;
 $show = null;
 
if (isset($_POST['user'])) {
  $username = trim($_POST['user']);
  $username = strip_tags($username);
  $username = htmlspecialchars($username);
  
  $password1 = trim($_POST['password']);
  $password1 = strip_tags($password1);
  $password1 = htmlspecialchars($password1);
 
  $cpassword = $_POST['confirmpassword'];
  $cpassword = strip_tags($cpassword);
  $cpassword = htmlspecialchars($cpassword);
  $user1 = '-sshieph';


$users = $username . $user1;

	$password1 = $_POST['password'];
	
	$datess = date('m/d/y', strtotime('+'.$nDays.' days'));
	$password = escapeshellarg( crypt($password1) );
     
	   
   if (strlen($username) < 3) {
   array_push($errors, "Username must have atleast 3 characters");
  }
  
   if(strlen($password1) < 3) {
   array_push($errors, "Password must have atleast 3 characters");
  }
  
  if($password1 != $cpassword){
	 array_push($errors, "Password Didn't match");
  } 

   if( !$error ) {
date_default_timezone_set('UTC');
date_default_timezone_set("Asia/Manila"); 
$my_date = date("Y-m-d H:i:s");
	   
	   

$connection = ssh2_connect($hosts, 22);
if (ssh2_auth_password($connection, 'root', $vpspass)) {
	$check_user = ssh2_exec($connection, "id -u $users");
                        $check_user_error = ssh2_fetch_stream($check_user, SSH2_STREAM_STDERR);
                          stream_set_blocking($check_user_error, true);
                            stream_set_blocking($check_user, true);
                            $stream_check_user_error = stream_get_contents($check_user_error);
                           $stream_check_user = stream_get_contents($check_user);
                           if ( !empty($stream_check_user))
                               {
                                   array_push($errors, "Username Already exist");
                               }
					
	if (count($errors) == 0) {
		$insert = mysqli_query($db,$query);
   $update = mysqli_query($db,$query2);
	

$show = true;
	
	 
ssh2_exec($connection, "useradd $users -m -p $password -e $datess -d  /home/$users -s /bin/false");
	}
            $succ = 'Added Succesfully';
			
	
   if ($res) {
    $errTyp = "success";
    $errMSG = "Successfully registered, you may Check your credentials";
    $username = '';
    $password = '';
    $cpassword = '';
	
   } else {
    $errTyp = "danger";
    $errMSG = "Something went wrong, try again later..."; 
   } 

} else {
        die('Connection Failed...');
}	
	 }   
  }
  
	
	
include('header.php'); ?>

<ul class="breadcrumb">
  <li><a href="/index.php"><i class="fa fa-home"></i>Home</a></li>
  <li style="text-transform:uppercase"><?php echo $svname; ?></li>
</ul>

<!-- Price area starts -->
    <section class="pricing-area section-big">
        <div class="container">

            <div class="row">
                <div class="col-md-12">
                    <div class="section-title text-center">
                        <h2>IEPH SSH</h2>                        
                        <p>IEPHSSH is the only true Top Tier SSH service in the world. This means we deliver the best SSH speeds, 
						The most secure connections and the most competitive SSH Provider in the world. IEPHSSH will give you the ability
						to surf anonymously and access the unrestricted Internet every corner of the globe.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12 col-center-block">
                    <div class="price-item featured" data-connectors="1">
					
					<div class="info">
                        <p class="level">Server <?php echo $svid; ?></p>
                            <p class="price">
                                <span class="number" style="text-transform:uppercase"><?php echo $svname; ?></span>
                            </p>
                        </div>
						<form class="form-style-6 action="/create.php?id=<?php echo $svid; ?>" method="post">
                        <div class="features">
					
                            <?php echo display_error(); ?>
							
							
							
												<div class="form-group">
							<label for="username" class="cols-sm-2 control-label">Username</label>
							
							
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-user fa-lg" aria-hidden="true"></i></span>
									<input type="text" class="form-control" name="user" id="username"  placeholder="Enter your Username" value="<?php echo $username ?>" required>
									
								</div>
							
						</div>

						<div class="form-group">
							<label for="password" class="cols-sm-2 control-label">Password</label>
							
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
									<input type="password" class="form-control" name="password" id="password"  placeholder="Enter your Password"  value="<?php echo $password1 ?>" required>
								</div>
							
						</div>

						<div class="form-group">
							<label for="confirm" class="cols-sm-2 control-label">Confirm Password</label>
							
						
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
									<input type="password" class="form-control" name="confirmpassword" id="confirm"  placeholder="Confirm your Password" required>
								</div>
							
						</div>
					
						<div class="form-group ">
							<input type="submit" id="button" class="btn btn-primary btn-lg btn-block login-button" name="insert" value="Register"><br />
							
						</div>
						
<div class="form-group ">
						
						<?php
						
						if($show == true) {
						echo '<div class="alert alert-info">';
					    echo "<Center><br><br>"; echo 'Account Details'; echo "</Center>"; echo "<br />";
						 
						echo 'Host: ';echo $svip; echo "<br />";
						echo 'Username:'; echo '&nbsp;'; echo $users; echo "<br />";
						echo 'Password:'; echo '&nbsp;'; echo $password1; echo "<br />";
						echo '<tr>'; echo '<td>SSH Port:</td>';echo '&nbsp;'; echo '<td>'; echo $port_ssh; echo '</td>'; echo '</tr>';echo '<br>';
                                        echo '<tr>'; echo '<td>Dropbear Port:</td>';echo '&nbsp;'; echo '<td>'; echo $port_dropbear; echo '</td>'; echo '</tr>';echo '<br>';
                                        echo '<tr>'; echo '<td>SSL Port:</td>';echo '&nbsp;'; echo '<td>'; echo $port_ssl; echo '</td>'; echo '</tr>';echo '<br>';
                                        echo '<tr>'; echo '<td>Squid Port:</td>';echo '&nbsp;'; echo '<td>'; echo $port_squid; echo '</td>'; echo '</tr>';echo '<br>';
						 
						 echo 'Date Expired:'; echo '&nbsp;'; echo $datess; echo "<br />";
						 
						
						}
						?>


						
                                       
 
                                          
                                        </div>
                                    </div>
						
                    </div>
					</form>
                </div>
                
</div>
    </section>
	
	
	
	
	
           <section class="pricing-area section-big">
        <div class="container">
		   <div class="row">
		   <div class="col-md-12">
		   <h3>What is SSH?</h3>
Sometimes, we keep our servers local. We can plug in a keyboard, mouse and monitor and control the server, as needed. More effectively and far more commonly these days, a lot of our servers live in a colo (co-location facility where many, many servers are hosted in an appropriate environment with cooling, throughput of data, physical security, etc.) or servers are virtualized like in Amazon Web Services or Microsoft Azure. So, without physical access to get to a shell, we can use Secure Shell. 

SSH uses an encrypted network connection to connect to a server and allows the user to run shell commands to a server remotely as if they were sitting right in front of it. It is a step up from something called Telnet which essentially does the same thing but does not use an encrypted connection. Telnet comes through as plaintext. Telnet would be the HTTP to SSH's HTTPS in this analogy. It is mostly deprecated this day and age. 

Now, when I say server, let me clarify something: Any computer can be SSH'd to so long as an SSH server instance is running on that machine. Most server OSes have an SSH server instance at least installed on them that might just need to be activated with a few settings. But, even your home computer could technically run an SSH server and be accessed via a secure shell client (assuming other security processes, such as firewalls or anti-viruses allow the connection to be made).
<br><br>


<h3>What is OVPN?</h3>
OpenVPN is both a VPN protocol and software that uses VPN techniques to secure point-to-point and site-to-site connections. Currently, it's one of the most popular VPN protocols among VPN users. 

Programmed by James Yonan and released in 2001, OpenVPN is one of the only open-source VPN protocols that also has its own open-source application (SoftEther being the other one).
</div></div>
</div>
    </section>
	
	
<?php include('footer.php'); ?>