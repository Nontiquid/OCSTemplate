<?php 
	session_start();
	
	$dbhost = 'localhost'; // phpmyadmin host mo
	$dbusername = 'root';  // phpmyadmin username
	$dbpass = '';          // phpmyadmin password
	$dbname = 'ieph-raf';  // name ng database mo

	// connect to database
	$db = mysqli_connect($dbhost, $dbusername, $dbpass, $dbname);

	// variable declaration
	$errors   = array(); 
	
	
	function display_error() {
		global $errors;

		if (count($errors) > 0){
			echo '<div class="alert alert-danger">';
				foreach ($errors as $error){
					echo $error .'<br>';
				}
			echo '</div>';
		}
	}
	?>